var a = function() { 1; }
a()
