(
    function(){1;}
)();
