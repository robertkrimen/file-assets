(
    function(){1;}
)();
