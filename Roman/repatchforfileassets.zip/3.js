﻿(
    function(){1;}
)();
